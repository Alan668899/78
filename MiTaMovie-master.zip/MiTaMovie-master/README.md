# MiTaMovie
Android利用Jsoup解析视频网站html，获取电影、电视剧、动漫、电视直播等播放资源


### 原理
https://www.jianshu.com/p/478a6d0d0dd5

### 体验地址

https://raw.githubusercontent.com/Mitaxing/XingMiMovie/master/xingmi.apk

### 项目交流

欢迎加入QQ群讨论：847083651
