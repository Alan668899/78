package com.xing.mita.movie.upnp.entity;

/**
 * 说明：
 * 作者：zhouzhan
 * 日期：17/6/27 17:47
 */

public interface IDevice<T> {

    T getDevice();
}
