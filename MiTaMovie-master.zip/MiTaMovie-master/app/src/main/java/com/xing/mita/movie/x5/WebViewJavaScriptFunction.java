package com.xing.mita.movie.x5;

public interface WebViewJavaScriptFunction {

	void onJsFunctionCalled(String tag);
}
