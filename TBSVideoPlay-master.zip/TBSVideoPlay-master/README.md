# TBSVideoPlay
利用腾讯浏览服务TBS，在Android应用内实现视频的播放，支持视频格式远多于系统WebView

## 效果图
<div>
<img src="https://github.com/yangxch/TBSVideoPlay/raw/master/screenshot/vertical_screen.jpg" width="32%" height="32%">
  <br><br>
<img src="https://github.com/yangxch/TBSVideoPlay/raw/master/screenshot/horizontal_screen.png" width="55%" height="32%">
</div>

***
更多技术干货，欢迎关注我的公众号：ChaoYoung
<br><img src="https://github.com/yangxch/TBSVideoPlay/raw/master/screenshot/qrcode_chaoyoung.jpg" width="20%" height="20%">


